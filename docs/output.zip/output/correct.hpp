#ifndef _CORRECT_H_
#define _CORRECT_H_
#include "base.hpp"


extern void goToBall(float heading);
extern void goToBall(float heading, bool override);
// extern void correction(float heading, float bx, float by);
// extern void lastCorrect(float heading, float by);
// extern void lastCorrect(float heading, float bx, float by);


#endif

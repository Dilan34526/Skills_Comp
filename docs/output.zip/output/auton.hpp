#ifndef _AUTON_H_
#define _AUTON_H_

/*
* Based on the autonomous selector pros project,
* choose the input and run the function
*/

/*
* @func: all autonomous inputs
*/
extern void auton(); 

#endif

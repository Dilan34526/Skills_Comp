#ifndef _CONTROLLER_H_
#define _CONTROLLER_H_

/*
* @func: all controller inputs
*   When the driver chooses a button, it will run a certain command
*/
extern void controllerInput();

#endif
